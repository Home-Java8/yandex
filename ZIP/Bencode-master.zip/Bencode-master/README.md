Bencode
=======

Java implementation of the encoding that used by the peer-to-peer file sharing system BitTorrent!

package com.ashlux.example.cliparsing.args4j;

public enum Genre
{
    ACTION,
    COMEDY,
    SCI_FI,
    FANTASY
}
